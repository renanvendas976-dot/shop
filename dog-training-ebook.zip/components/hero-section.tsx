import { Button } from "@/components/ui/button"
import { ArrowRight, Star } from "lucide-react"
import Image from "next/image"

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-background pt-16 pb-24 md:pt-24 md:pb-32">
      <div className="container mx-auto px-4">
        <div className="grid gap-12 lg:grid-cols-2 lg:gap-16 items-center">
          <div className="space-y-8">
            <div className="inline-flex items-center gap-2 rounded-full bg-secondary/50 px-4 py-2 text-sm font-medium text-secondary-foreground">
              <Star className="h-4 w-4 fill-accent text-accent" />
              <span>Mais de 5.000 cães treinados com sucesso</span>
            </div>

            <h1 className="text-balance text-4xl font-bold tracking-tight text-foreground md:text-5xl lg:text-6xl">
              Transforme Seu Cão em um Companheiro Obediente
            </h1>

            <p className="text-pretty text-lg text-muted-foreground leading-relaxed md:text-xl">
              Descubra os métodos comprovados que profissionais usam para treinar cães de todas as raças e idades. Um
              guia completo e prático para você aplicar hoje mesmo.
            </p>

            <div className="flex flex-col gap-4 sm:flex-row">
              <Button size="lg" className="text-lg h-14 px-8 bg-primary hover:bg-primary/90">
                Comprar Agora
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-lg h-14 px-8 bg-transparent">
                Ver Prévia Grátis
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div>
                <div className="text-3xl font-bold text-foreground">5.000+</div>
                <div className="text-sm text-muted-foreground">Leitores Satisfeitos</div>
              </div>
              <div className="h-12 w-px bg-border" />
              <div>
                <div className="flex items-center gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-accent text-accent" />
                  ))}
                </div>
                <div className="text-sm text-muted-foreground mt-1">4.9 de 5 estrelas</div>
              </div>
            </div>
          </div>

          <div className="relative">
            <div className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-muted shadow-2xl">
              <Image src="/happy-dog-being-trained-by-owner-in-park.jpg" alt="Cão sendo treinado" fill className="object-cover" priority />
            </div>
            <div className="absolute -bottom-6 -left-6 rounded-xl bg-card p-6 shadow-xl border border-border">
              <div className="text-sm font-medium text-muted-foreground">Resultados em</div>
              <div className="text-3xl font-bold text-primary">7 Dias</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
