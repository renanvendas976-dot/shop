import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle2 } from "lucide-react"

const chapters = [
  {
    title: "Capítulo 1: Fundamentos do Comportamento Canino",
    topics: ["Como os cães pensam e aprendem", "Linguagem corporal canina", "Estabelecendo liderança positiva"],
  },
  {
    title: "Capítulo 2: Comandos Básicos Essenciais",
    topics: ["Sentar, deitar e ficar", "Vir quando chamado", "Andar na coleira sem puxar"],
  },
  {
    title: "Capítulo 3: Corrigindo Comportamentos Indesejados",
    topics: ["Latidos excessivos", "Pular nas pessoas", "Destruição de objetos"],
  },
  {
    title: "Capítulo 4: Socialização e Convivência",
    topics: ["Interação com outros cães", "Comportamento com estranhos", "Adaptação a novos ambientes"],
  },
]

export function PreviewSection() {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="grid gap-12 lg:grid-cols-2 items-center">
          <div>
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl mb-6">
              O Que Você Vai Aprender
            </h2>
            <p className="text-pretty text-lg text-muted-foreground leading-relaxed mb-8">
              Mais de 150 páginas de conteúdo prático, ilustrado com fotos e diagramas explicativos. Cada capítulo
              inclui exercícios práticos e dicas de solução de problemas.
            </p>

            <div className="space-y-6">
              {chapters.map((chapter, index) => (
                <Card key={index} className="border-border">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-semibold text-foreground mb-3">{chapter.title}</h3>
                    <ul className="space-y-2">
                      {chapter.topics.map((topic, topicIndex) => (
                        <li key={topicIndex} className="flex items-start gap-2">
                          <CheckCircle2 className="h-5 w-5 text-primary mt-0.5 flex-shrink-0" />
                          <span className="text-muted-foreground">{topic}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div className="relative">
            <div className="relative aspect-[3/4] overflow-hidden rounded-2xl bg-muted shadow-2xl border-4 border-primary/20">
              <img src="/ebook-cover-about-dog-training-with-happy-dog.jpg" alt="Capa do Ebook" className="object-cover w-full h-full" />
            </div>
            <div className="absolute -top-6 -right-6 rounded-full bg-accent text-accent-foreground px-6 py-3 shadow-xl font-bold text-lg">
              150+ Páginas
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
