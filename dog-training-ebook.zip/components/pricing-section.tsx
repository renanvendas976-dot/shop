import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { CheckCircle2, ArrowRight } from "lucide-react"

const features = [
  "Ebook completo com 150+ páginas",
  "Guia ilustrado passo a passo",
  "Acesso imediato após a compra",
  "Atualizações gratuitas vitalícias",
  "Garantia de 30 dias",
  "Suporte por email",
]

export function PricingSection() {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl mb-4">
              Comece Hoje Mesmo
            </h2>
            <p className="text-pretty text-lg text-muted-foreground">
              Investimento único para uma vida inteira de harmonia com seu cão.
            </p>
          </div>

          <Card className="border-2 border-primary shadow-2xl">
            <CardContent className="p-8 md:p-12">
              <div className="text-center mb-8">
                <div className="inline-block rounded-full bg-accent/10 px-4 py-2 text-sm font-semibold text-accent mb-4">
                  Oferta Especial
                </div>
                <div className="flex items-center justify-center gap-3 mb-2">
                  <span className="text-2xl text-muted-foreground line-through">R$ 197</span>
                  <span className="text-5xl font-bold text-foreground">R$ 97</span>
                </div>
                <p className="text-muted-foreground">Pagamento único • Sem mensalidades</p>
              </div>

              <div className="space-y-4 mb-8">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center gap-3">
                    <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0" />
                    <span className="text-foreground text-lg">{feature}</span>
                  </div>
                ))}
              </div>

              <Button size="lg" className="w-full text-lg h-14 bg-primary hover:bg-primary/90">
                Comprar Agora por R$ 97
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>

              <p className="text-center text-sm text-muted-foreground mt-6">
                🔒 Pagamento 100% seguro • Garantia de 30 dias ou seu dinheiro de volta
              </p>
            </CardContent>
          </Card>

          <div className="mt-12 text-center">
            <Card className="border-border bg-muted/50">
              <CardContent className="p-6">
                <h3 className="text-xl font-semibold text-foreground mb-2">Garantia de Satisfação</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Se você não ver resultados em 30 dias, devolvemos 100% do seu dinheiro. Sem perguntas, sem
                  complicações.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  )
}
