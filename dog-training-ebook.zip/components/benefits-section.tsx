import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, Clock, Award, Users, Heart, Zap } from "lucide-react"

const benefits = [
  {
    icon: BookOpen,
    title: "Método Passo a Passo",
    description: "Instruções claras e detalhadas que qualquer pessoa pode seguir, mesmo sem experiência prévia.",
  },
  {
    icon: Clock,
    title: "Resultados Rápidos",
    description: "Veja mudanças comportamentais significativas em apenas 7 dias de treinamento consistente.",
  },
  {
    icon: Award,
    title: "Técnicas Profissionais",
    description: "Aprenda os mesmos métodos usados por treinadores certificados em todo o mundo.",
  },
  {
    icon: Users,
    title: "Para Todas as Raças",
    description: "Funciona com cães de qualquer raça, tamanho ou idade - do filhote ao adulto.",
  },
  {
    icon: Heart,
    title: "Baseado em Reforço Positivo",
    description: "Métodos gentis e eficazes que fortalecem o vínculo entre você e seu cão.",
  },
  {
    icon: Zap,
    title: "Acesso Imediato",
    description: "Baixe o ebook instantaneamente após a compra e comece o treinamento hoje.",
  },
]

export function BenefitsSection() {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl mb-4">
            Por Que Este Ebook é Diferente?
          </h2>
          <p className="text-pretty text-lg text-muted-foreground max-w-2xl mx-auto">
            Um guia completo que combina ciência comportamental com experiência prática de anos treinando cães.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {benefits.map((benefit, index) => (
            <Card key={index} className="border-border hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                  <benefit.icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-semibold text-foreground mb-2">{benefit.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{benefit.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
