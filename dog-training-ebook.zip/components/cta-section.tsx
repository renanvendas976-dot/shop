import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react"

export function CTASection() {
  return (
    <section className="py-24 bg-primary text-primary-foreground">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-balance text-3xl font-bold tracking-tight md:text-4xl lg:text-5xl mb-6">
            Pronto Para Transformar Seu Cão?
          </h2>
          <p className="text-pretty text-lg mb-8 opacity-90 leading-relaxed">
            Junte-se a milhares de donos satisfeitos que já transformaram a vida de seus cães. Comece hoje e veja
            resultados em apenas 7 dias.
          </p>
          <Button size="lg" variant="secondary" className="text-lg h-14 px-8">
            Garantir Minha Cópia Agora
            <ArrowRight className="ml-2 h-5 w-5" />
          </Button>
        </div>
      </div>
    </section>
  )
}
