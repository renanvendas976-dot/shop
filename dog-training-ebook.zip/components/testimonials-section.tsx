import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"
import Image from "next/image"

const testimonials = [
  {
    name: "Maria Silva",
    role: "Dona do Max, Labrador",
    content:
      "Em apenas 2 semanas, meu Max parou de pular nas visitas e aprendeu a sentar no comando. Este ebook mudou nossa vida!",
    rating: 5,
    image: "/woman-and-loyal-companion.png",
  },
  {
    name: "João Santos",
    role: "Dono da Luna, Border Collie",
    content:
      "Métodos claros e eficazes. A Luna agora obedece todos os comandos básicos e nossos passeios ficaram muito mais agradáveis.",
    rating: 5,
    image: "/man-and-loyal-companion.png",
  },
  {
    name: "Ana Costa",
    role: "Dona do Thor, Pastor Alemão",
    content:
      "Estava desesperada com os latidos do Thor. Segui o guia e em 10 dias ele estava muito mais calmo. Recomendo demais!",
    rating: 5,
    image: "/diverse-woman-smiling.png",
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-balance text-3xl font-bold tracking-tight text-foreground md:text-4xl lg:text-5xl mb-4">
            O Que Nossos Leitores Dizem
          </h2>
          <p className="text-pretty text-lg text-muted-foreground max-w-2xl mx-auto">
            Milhares de donos de cães já transformaram a relação com seus pets usando nosso método.
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-border">
              <CardContent className="p-6">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="h-5 w-5 fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-foreground leading-relaxed mb-6">"{testimonial.content}"</p>
                <div className="flex items-center gap-3">
                  <div className="relative h-12 w-12 overflow-hidden rounded-full bg-muted">
                    <Image
                      src={testimonial.image || "/placeholder.svg"}
                      alt={testimonial.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <div className="font-semibold text-foreground">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
